# -*- coding: utf-8 -*-
# ==========================================
# Version: v20261004.019
# ==========================================

import pygame
import random
import sys
import math
import time
import io
import wave
import struct
import asyncio

# Web 환경에서는 무거운 네트워크 모듈 원천 차단 (패키징 용량 최소화)
IS_WEB = sys.platform == "emscripten"
if not IS_WEB:
    import json
    import threading
    import urllib.request

pygame.init()
pygame.font.init()
try:
    pygame.mixer.init(frequency=22050, size=-16, channels=1, buffer=512)
except Exception:
    pass

def create_wave_sound(samples, framerate=22050):
    try:
        buf = io.BytesIO()
        with wave.open(buf, 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(framerate)
            raw = bytearray()
            for s in samples:
                clamped = max(-32767, min(32767, int(s * 32767)))
                raw.extend(struct.pack('<h', clamped))
            wf.writeframes(raw)
        buf.seek(0)
        return pygame.mixer.Sound(buf)
    except Exception:
        return None

def gen_sfx_explosion_1():
    samples = []
    sr = 22050
    dur = 0.35
    total = int(sr * dur)
    for i in range(total):
        t = i / sr
        freq = 130.0 * (1.0 - t/dur)**2 + 35.0
        env = (1.0 - t/dur)**1.8
        sine = math.sin(2 * math.pi * freq * t)
        noise = (random.random() * 2.0 - 1.0) * 0.4
        samples.append((sine * 0.6 + noise * 0.4) * env * 0.8)
    return create_wave_sound(samples)

def gen_sfx_explosion_2():
    samples = []
    sr = 22050
    dur = 0.25
    total = int(sr * dur)
    for i in range(total):
        t = i / sr
        freq = 420.0 * (1.0 - t/dur) + 80.0
        env = (1.0 - t/dur)**2.5
        square = 1.0 if math.sin(2 * math.pi * freq * t) > 0 else -1.0
        noise = (random.random() * 2.0 - 1.0) * 0.6
        samples.append((square * 0.3 + noise * 0.7) * env * 0.75)
    return create_wave_sound(samples)

def gen_sfx_explosion_3():
    samples = []
    sr = 22050
    dur = 0.22
    total = int(sr * dur)
    for i in range(total):
        t = i / sr
        freq = 880.0 * (1.0 - (t/dur)**0.5) + 60.0
        env = (1.0 - t/dur)**3.0
        chirp = math.sin(2 * math.pi * freq * t)
        samples.append(chirp * env * 0.8)
    return create_wave_sound(samples)

def gen_sfx_slot_tick():
    samples = []
    sr = 22050
    dur = 0.05
    total = int(sr * dur)
    for i in range(total):
        t = i / sr
        freq = 1200.0 - (t / dur) * 600.0
        env = (1.0 - t / dur)**2
        samples.append(math.sin(2 * math.pi * freq * t) * env * 0.5)
    return create_wave_sound(samples)

def gen_synthwave_bgm():
    sr = 22050
    bpm = 132
    beat_dur = 60.0 / bpm
    total_beats = 64
    total_dur = beat_dur * total_beats
    total_samples = int(sr * total_dur)
    samples = [0.0] * total_samples

    bass_notes = [55.0, 55.0, 65.4, 73.4, 49.0, 49.0, 55.0, 61.7]
    lead_notes = [220.0, 261.6, 293.6, 329.6, 392.0, 329.6, 293.6, 261.6]

    for i in range(total_samples):
        t = i / sr
        beat_idx = int(t / beat_dur)
        beat_pos = (t % beat_dur) / beat_dur

        kick = 0.0
        if beat_pos < 0.25:
            kt = beat_pos * beat_dur
            k_freq = 120.0 * (1.0 - kt / 0.15)**3 + 45.0
            kick = math.sin(2 * math.pi * k_freq * kt) * ((1.0 - beat_pos / 0.25)**2) * 0.55

        sub_beat_pos = (t % (beat_dur / 4)) / (beat_dur / 4)
        bfreq = bass_notes[(beat_idx // 4) % len(bass_notes)]
        saw = (2.0 * ((t * bfreq) % 1.0) - 1.0) * ((1.0 - sub_beat_pos)**1.5) * 0.22

        lead_idx = int((t % (beat_dur * 2)) / (beat_dur / 2))
        lfreq = lead_notes[(lead_idx + beat_idx) % len(lead_notes)]
        lead_pos = (t % (beat_dur / 2)) / (beat_dur / 2)
        lead = math.sin(2 * math.pi * lfreq * t) * ((1.0 - lead_pos)**2) * 0.18

        samples[i] = kick + saw + lead

    return create_wave_sound(samples)

SFX_EXPLOSIONS = [s for s in [gen_sfx_explosion_1(), gen_sfx_explosion_2(), gen_sfx_explosion_3()] if s]
SFX_SLOT_TICK = gen_sfx_slot_tick()
BGM_SOUND = gen_synthwave_bgm()
if BGM_SOUND:
    try:
        BGM_SOUND.play(loops=-1)
    except Exception:
        pass

CONFIG = {
    "BASE_PLAYER_SPEED": 5.2,
    "STAT_SPEED_FACTOR": 0.65,
    "BASE_FIRE_INTERVAL": 0.405,
    "FIRE_RATE_REDUCTION": 0.05,
    "HIT_PROBABILITY": 0.50,
    "TARGET_HP_PRESSURE_RATIO": 0.85,
    "MIN_SPAWN_INTERVAL": 0.22,
    "MAX_SPAWN_INTERVAL": 1.20,
    "MAX_ENEMY_HP_CAP": 20,
    "BASE_ENEMY_SPEED": 3.6,
    "LASER_WEAPON_INTERVAL": 1.0,
    "LASER_WEAPON_DURATION": 30.5,
    "LASER_BEAM_LINGER_TIME": 0.2,
    "CLONE_SHIP_DURATION": 30.0,
    "SHIELD_DURATION": 30.0,
    "INVINCIBLE_TIME_ON_SHIELD_BREAK": 0.6,
    "MAX_SKILL_GAUGE": 100.0,
    "GAUGE_PER_KILL": 4.9,
    "SLOT_CYCLE_INTERVAL": 0.3,
    "SLOT_AUTO_PICK_TIMEOUT": 5.0,
    "SLOT_RESULT_DISPLAY_TIME": 2.0,
    "POWER_DROP_SPEED": 3.6,
    "GRAZE_DISTANCE": 32.0,
    "GRAZE_GAUGE_BONUS": 0.5,
    "BOSS_SPAWN_INTERVAL": 60.0
}

VERSION_STR = "v20261004.019"
SCREEN_WIDTH = 450
SCREEN_HEIGHT = 800
FPS = 60

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption(f"Neon Flight: Overdrive - {VERSION_STR}")
clock = pygame.time.Clock()

COLOR_BG = (8, 8, 20)
COLOR_CYAN = (0, 245, 255)
COLOR_MAGENTA = (255, 0, 128)
COLOR_YELLOW = (255, 230, 0)
COLOR_WHITE = (255, 255, 255)
COLOR_GRAY = (80, 80, 100)
COLOR_GREEN = (50, 255, 120)
COLOR_ORANGE = (255, 140, 0)
COLOR_DARK_BLUE = (20, 25, 45)
COLOR_RED = (255, 40, 40)
COLOR_VERSION_DIM = (55, 55, 75)

FONT_XL = pygame.font.SysFont("arial", 28, bold=True)
FONT_L = pygame.font.SysFont("arial", 24, bold=True)
FONT_M = pygame.font.SysFont("arial", 16, bold=True)
FONT_S = pygame.font.SysFont("arial", 13)
FONT_LIST = pygame.font.SysFont("arial", 11)
FONT_TOP10 = pygame.font.SysFont("consolas", 11)
FONT_VER = pygame.font.SysFont("consolas", 11)
FONT_TIMER = pygame.font.SysFont("consolas", 11, bold=True)

STATE_SELECT = 0
STATE_BATTLE = 1
STATE_SLOT = 2
STATE_GAMEOVER = 3
game_state = STATE_SELECT

shake_intensity = 0.0
shake_decay = 18.0

def add_screen_shake(amount):
    global shake_intensity
    shake_intensity = min(16.0, shake_intensity + amount)

FIREBASE_URL = "https://flywm-d0b39-default-rtdb.asia-southeast1.firebasedatabase.app/leaderboard_flight.json"
top10_list = []

def fetch_top10_async():
    if IS_WEB:
        return
    def _worker():
        global top10_list
        try:
            req = urllib.request.Request(FIREBASE_URL, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=3.0) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                if data and isinstance(data, dict):
                    items = []
                    for v in data.values():
                        if isinstance(v, dict) and "name" in v and "score" in v:
                            items.append((str(v["name"]), int(v["score"])))
                    items.sort(key=lambda x: x[1], reverse=True)
                    top10_list = items[:10]
        except Exception:
            pass
    threading.Thread(target=_worker, daemon=True).start()

def upload_score_async(player_name, final_score):
    if IS_WEB:
        return
    def _worker():
        try:
            payload = json.dumps({"name": player_name, "score": final_score, "time": time.time()}).encode('utf-8')
            req = urllib.request.Request(FIREBASE_URL, data=payload, headers={'Content-Type': 'application/json'}, method='POST')
            with urllib.request.urlopen(req, timeout=3.0) as resp:
                resp.read()
            fetch_top10_async()
        except Exception:
            pass
    threading.Thread(target=_worker, daemon=True).start()

fetch_top10_async()

TIER_THEMES = [
    {"bg": (8, 8, 20), "star_tint": (180, 200, 255)},
    {"bg": (12, 5, 24), "star_tint": (255, 180, 230)},
    {"bg": (4, 18, 26), "star_tint": (150, 255, 240)},
    {"bg": (24, 8, 8), "star_tint": (255, 200, 150)}
]
current_tier = 0

class Star:
    def __init__(self):
        self.x = random.randint(0, SCREEN_WIDTH)
        self.y = random.randint(0, SCREEN_HEIGHT)
        self.speed = random.uniform(0.6, 2.2)
        self.size = 1 if self.speed < 1.3 else 2
        self.brightness = random.randint(70, 160)

    def update(self):
        self.y += self.speed
        if self.y > SCREEN_HEIGHT:
            self.y = 0
            self.x = random.randint(0, SCREEN_WIDTH)

    def draw(self, surf, tint):
        r = int(self.brightness * (tint[0] / 255.0))
        g = int(self.brightness * (tint[1] / 255.0))
        b = int(self.brightness * (tint[2] / 255.0))
        pygame.draw.circle(surf, (min(255, r), min(255, g), min(255, b)), (int(self.x), int(self.y)), self.size)

stars = [Star() for _ in range(65)]

class Planet:
    def __init__(self, x, y, radius, color, has_ring=False):
        self.x = x
        self.y = y
        self.radius = radius
        self.color = color
        self.has_ring = has_ring
        self.speed = random.uniform(0.18, 0.40)

    def update(self):
        self.y += self.speed
        if self.y - self.radius > SCREEN_HEIGHT + 60:
            self.y = -self.radius - random.randint(40, 180)
            self.x = random.randint(30, SCREEN_WIDTH - 30)

    def draw(self, surf):
        surf_p = pygame.Surface((self.radius * 4, self.radius * 4), pygame.SRCALPHA)
        cx, cy = self.radius * 2, self.radius * 2
        pygame.draw.circle(surf_p, (*self.color, 42), (cx, cy), self.radius)
        pygame.draw.circle(surf_p, (255, 255, 255, 25), (cx - int(self.radius*0.3), cy - int(self.radius*0.3)), int(self.radius*0.6))
        if self.has_ring:
            rect = pygame.Rect(cx - int(self.radius*1.8), cy - int(self.radius*0.4), int(self.radius*3.6), int(self.radius*0.8))
            pygame.draw.ellipse(surf_p, (*self.color, 48), rect, 3)
        surf.blit(surf_p, (self.x - cx, self.y - cy))

planets = [
    Planet(70, 100, 42, (70, 110, 220), has_ring=True),
    Planet(350, 360, 32, (210, 80, 140), has_ring=False),
    Planet(180, -60, 48, (160, 100, 60), has_ring=True),
    Planet(300, 680, 26, (50, 170, 140), has_ring=False)
]

class RareSpaceObject:
    def __init__(self):
        self.active_obj = None
        self.last_spawn_time = time.time() - 30.0
        self.cooldown = 60.0

    def update(self, cur_time):
        if self.active_obj is None:
            if cur_time - self.last_spawn_time >= self.cooldown:
                obj_type = random.choice(["GALAXY", "DEBRIS", "BLACKHOLE"])
                self.active_obj = {
                    "type": obj_type,
                    "x": random.randint(70, SCREEN_WIDTH - 70),
                    "y": -120.0,
                    "speed": random.uniform(0.20, 0.40)
                }
                self.last_spawn_time = cur_time
        else:
            self.active_obj["y"] += self.active_obj["speed"]
            if self.active_obj["y"] > SCREEN_HEIGHT + 130:
                self.active_obj = None
                self.last_spawn_time = cur_time

    def draw(self, surf):
        if not self.active_obj:
            return
        o_type = self.active_obj["type"]
        x, y = self.active_obj["x"], self.active_obj["y"]

        if o_type == "BLACKHOLE":
            s = pygame.Surface((140, 140), pygame.SRCALPHA)
            pygame.draw.ellipse(s, (255, 120, 0, 42), (10, 50, 120, 40), 4)
            pygame.draw.ellipse(s, (180, 50, 240, 28), (25, 40, 90, 60), 2)
            pygame.draw.circle(s, (5, 5, 10, 240), (70, 70), 22)
            pygame.draw.circle(s, (0, 245, 255, 80), (70, 70), 24, 1)
            surf.blit(s, (x - 70, y - 70))

        elif o_type == "GALAXY":
            s = pygame.Surface((150, 150), pygame.SRCALPHA)
            for rad in range(12, 50, 10):
                pygame.draw.ellipse(s, (130, 170, 240, 22), (75 - rad, 75 - rad // 2, rad * 2, rad), 2)
            pygame.draw.circle(s, (255, 255, 255, 55), (75, 75), 8)
            surf.blit(s, (x - 75, y - 75))

        elif o_type == "DEBRIS":
            s = pygame.Surface((70, 70), pygame.SRCALPHA)
            pts = [(20, 15), (48, 22), (35, 45), (15, 38)]
            pygame.draw.polygon(s, (45, 50, 65, 35), pts)
            pygame.draw.polygon(s, (70, 75, 95, 45), pts, 1)
            pygame.draw.line(s, (110, 80, 80, 30), (22, 18), (38, 38), 1)
            surf.blit(s, (x - 35, y - 35))

rare_space_manager = RareSpaceObject()

def draw_pixel_matrix(surf, cx, cy, matrix, color_map, pixel_size=3):
    rows = len(matrix)
    cols = len(matrix[0])
    start_x = int(cx - (cols * pixel_size) / 2)
    start_y = int(cy - (rows * pixel_size) / 2)
    for r_idx, row in enumerate(matrix):
        for c_idx, val in enumerate(row):
            if val != 0 and val in color_map:
                col = color_map[val]
                pygame.draw.rect(surf, col, (start_x + c_idx * pixel_size, start_y + r_idx * pixel_size, pixel_size, pixel_size))

PIXEL_PLAYERS = {
    0: [
        [0,0,0,0,0,1,1,0,0,0,0,0],
        [0,0,0,0,1,2,2,1,0,0,0,0],
        [0,0,0,1,1,2,2,1,1,0,0,0],
        [0,0,1,1,3,2,2,3,1,1,0,0],
        [0,1,1,1,3,2,2,3,1,1,1,0],
        [1,1,0,1,1,3,3,1,1,0,1,1],
        [1,0,0,1,1,1,1,1,1,0,0,1],
        [1,0,1,1,1,4,4,1,1,1,0,1],
        [0,0,1,0,4,0,0,4,0,1,0,0]
    ],
    1: [
        [0,0,0,1,1,1,1,1,1,0,0,0],
        [0,0,1,1,2,2,2,2,1,1,0,0],
        [0,1,1,2,3,3,3,3,2,1,1,0],
        [1,1,1,1,3,3,3,3,1,1,1,1],
        [1,1,1,1,1,1,1,1,1,1,1,1],
        [1,1,0,1,1,1,1,1,1,0,1,1],
        [1,0,0,1,1,1,1,1,1,0,0,1],
        [1,1,1,1,4,1,1,4,1,1,1,1],
        [0,1,0,4,4,0,0,4,4,0,1,0]
    ],
    2: [
        [1,1,0,0,0,1,1,0,0,0,1,1],
        [1,2,1,0,1,2,2,1,0,1,2,1],
        [1,2,1,0,1,3,3,1,0,1,2,1],
        [1,1,1,1,1,3,3,1,1,1,1,1],
        [1,1,1,1,1,1,1,1,1,1,1,1],
        [1,0,1,1,1,0,0,1,1,1,0,1],
        [1,0,4,0,0,0,0,0,0,4,0,1]
    ]
}

PIXEL_ENEMIES = [
    [[0,0,1,1,1,1,0,0],[0,1,2,2,2,2,1,0],[1,1,3,2,2,3,1,1],[1,1,1,1,1,1,1,1],[1,0,1,0,0,1,0,1],[0,1,0,0,0,0,1,0]],
    [[0,0,0,1,1,0,0,0],[0,0,1,2,2,1,0,0],[0,1,2,3,3,2,1,0],[1,2,3,3,3,3,2,1],[0,1,2,3,3,2,1,0],[0,0,1,2,2,1,0,0],[0,0,0,1,1,0,0,0]],
    [[1,0,0,0,0,0,0,1],[1,1,0,0,0,0,1,1],[1,1,1,0,0,1,1,1],[0,1,2,1,1,2,1,0],[0,0,1,2,2,1,0,0],[0,0,0,1,1,0,0,0]],
    [[1,1,1,1,1,1,1,1],[1,2,2,2,2,2,2,1],[1,3,1,2,2,1,3,1],[1,2,2,2,2,2,2,1],[0,1,1,0,0,1,1,0],[0,0,1,0,0,1,0,0]],
    [[1,0,0,0,1],[1,1,0,1,1],[1,2,1,2,1],[1,3,1,3,1],[1,1,1,1,1],[1,0,0,0,1]],
    [[0,1,1,1,1,1,1,0],[1,1,2,2,2,2,1,1],[1,3,1,2,2,1,3,1],[1,1,1,1,1,1,1,1],[1,0,1,0,0,1,0,1],[1,0,0,0,0,0,0,1]],
    [[0,0,0,1,1,0,0,0],[0,0,1,2,2,1,0,0],[0,1,1,3,3,1,1,0],[1,1,1,1,1,1,1,1],[1,0,1,0,0,1,0,1],[0,0,1,0,0,1,0,0]],
    [[1,0,0,0,0,1],[1,1,1,1,1,1],[0,1,2,2,1,0],[0,1,3,3,1,0],[1,1,1,1,1,1],[1,0,0,0,0,1]],
    [[0,0,1,1,0,0],[0,1,2,2,1,0],[1,2,3,3,2,1],[0,1,2,2,1,0],[0,0,1,1,0,0]],
    [[1,1,0,0,0,0,1,1],[1,2,1,1,1,1,2,1],[1,3,2,2,2,2,3,1],[1,2,2,2,2,2,2,1],[0,1,1,1,1,1,1,0],[0,0,1,0,0,1,0,0]]
]

PIXEL_BOSS = [
    [0,0,0,1,1,0,0,0,0,0,0,1,1,0,0,0],
    [0,0,1,2,2,1,0,0,0,0,1,2,2,1,0,0],
    [0,1,2,3,3,2,1,1,1,1,2,3,3,2,1,0],
    [1,2,3,3,3,3,2,2,2,2,3,3,3,3,2,1],
    [1,3,1,1,3,3,1,1,1,1,3,3,1,1,3,1],
    [1,3,1,1,3,3,3,3,3,3,3,3,1,1,3,1],
    [1,1,2,2,3,3,3,3,3,3,3,3,2,2,1,1],
    [0,1,1,1,2,2,2,2,2,2,2,2,1,1,1,0],
    [0,0,1,1,1,1,3,3,3,3,1,1,1,1,0,0],
    [0,0,0,1,1,0,2,2,2,2,0,1,1,0,0,0],
    [0,0,1,1,0,0,1,1,1,1,0,0,1,1,0,0],
    [0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0]
]

class ExplosionFX:
    def __init__(self, x, y, fx_type, color):
        self.x = x
        self.y = y
        self.fx_type = fx_type
        self.color = color
        self.life = 1.0
        self.decay = random.uniform(2.5, 4.0)
        self.elements = []
        if fx_type == 0:
            for _ in range(12):
                ang = random.uniform(0, math.pi * 2)
                spd = random.uniform(3, 7)
                self.elements.append({"x": x, "y": y, "vx": math.cos(ang)*spd, "vy": math.sin(ang)*spd, "r": random.uniform(3, 6)})
        elif fx_type == 1:
            self.elements.append({"r": 4.0, "max_r": 36.0, "width": 3})
        elif fx_type == 2:
            for ang in [math.pi/4, 3*math.pi/4, 5*math.pi/4, 7*math.pi/4]:
                spd = random.uniform(4, 8)
                self.elements.append({"x": x, "y": y, "vx": math.cos(ang)*spd, "vy": math.sin(ang)*spd, "r": 4})
        elif fx_type == 3:
            for _ in range(16):
                ang = random.uniform(0, math.pi * 2)
                spd = random.uniform(5, 11)
                self.elements.append({"x": x, "y": y, "vx": math.cos(ang)*spd, "vy": math.sin(ang)*spd, "r": 2})
        else:
            for _ in range(8):
                ang = random.uniform(0, math.pi * 2)
                spd = random.uniform(2, 5)
                self.elements.append({"x": x, "y": y, "vx": math.cos(ang)*spd, "vy": math.sin(ang)*spd, "s": random.randint(4, 7)})

    def update(self, dt):
        self.life -= self.decay * dt
        if self.fx_type in (0, 2, 3):
            for el in self.elements:
                el["x"] += el["vx"]
                el["y"] += el["vy"]
                el["r"] = max(0, el["r"] - dt * 2)
        elif self.fx_type == 1:
            self.elements[0]["r"] += 80.0 * dt
        elif self.fx_type == 4:
            for el in self.elements:
                el["x"] += el["vx"]
                el["y"] += el["vy"]

    def draw(self, surf):
        if self.life <= 0:
            return
        alpha = max(0, min(255, int(self.life * 255)))
        if self.fx_type in (0, 2, 3):
            for el in self.elements:
                if el["r"] > 0:
                    s = pygame.Surface((int(el["r"] * 2), int(el["r"] * 2)), pygame.SRCALPHA)
                    pygame.draw.circle(s, (*self.color, alpha), (int(el["r"]), int(el["r"])), int(el["r"]))
                    surf.blit(s, (el["x"] - el["r"], el["y"] - el["r"]))
        elif self.fx_type == 1:
            el = self.elements[0]
            rad = int(el["r"])
            s = pygame.Surface((rad * 2 + 6, rad * 2 + 6), pygame.SRCALPHA)
            pygame.draw.circle(s, (*self.color, alpha), (rad + 3, rad + 3), rad, int(el["width"]))
            surf.blit(s, (self.x - rad - 3, self.y - rad - 3))
        elif self.fx_type == 4:
            for el in self.elements:
                s = pygame.Surface((el["s"], el["s"]), pygame.SRCALPHA)
                s.fill((*self.color, alpha))
                surf.blit(s, (el["x"] - el["s"]//2, el["y"] - el["s"]//2))

class PowerDropItem:
    def __init__(self, start_x):
        self.x = float(start_x)
        self.y = -25.0
        self.speed = CONFIG["POWER_DROP_SPEED"]
        self.base_radius = 15.0

    def update(self):
        self.y += self.speed

    def draw(self, surf, cur_time):
        pulse = math.sin(cur_time * 8.0) * 3.0
        cur_r = max(10.0, self.base_radius + pulse)
        glow_color = COLOR_YELLOW if (int(cur_time * 12.0) % 2 == 0) else COLOR_ORANGE
        s_glow = pygame.Surface((int(cur_r * 4), int(cur_r * 4)), pygame.SRCALPHA)
        pygame.draw.circle(s_glow, (*COLOR_ORANGE, 80), (int(cur_r * 2), int(cur_r * 2)), int(cur_r + 4))
        surf.blit(s_glow, (self.x - cur_r * 2, self.y - cur_r * 2))
        pygame.draw.circle(surf, glow_color, (int(self.x), int(self.y)), int(cur_r))
        pygame.draw.circle(surf, COLOR_WHITE, (int(self.x), int(self.y)), int(cur_r), 2)
        txt = FONT_S.render("P", True, COLOR_WHITE)
        surf.blit(txt, (self.x - txt.get_width() // 2, self.y - txt.get_height() // 2))

class LaserBeamLine:
    def __init__(self, start_pos, target_pos, start_time):
        self.start_pos = start_pos
        self.target_pos = target_pos
        self.birth_time = start_time

    def is_expired(self, cur_time):
        return (cur_time - self.birth_time) >= CONFIG["LASER_BEAM_LINGER_TIME"]

    def draw(self, surf, cur_time):
        elapsed = cur_time - self.birth_time
        alpha = max(0, min(255, int((1.0 - (elapsed / CONFIG["LASER_BEAM_LINGER_TIME"])) * 255)))
        laser_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        pygame.draw.line(laser_surf, (*COLOR_CYAN, alpha), self.start_pos, self.target_pos, 3)
        pygame.draw.line(laser_surf, (*COLOR_WHITE, alpha), self.start_pos, self.target_pos, 1)
        surf.blit(laser_surf, (0, 0))

class SpawnWarning:
    def __init__(self, x, spawn_delay=0.35):
        self.x = x
        self.birth_time = time.time()
        self.spawn_delay = spawn_delay

    def is_ready(self, cur_time):
        return (cur_time - self.birth_time) >= self.spawn_delay

    def draw(self, surf, cur_time):
        alpha = int(180 + 75 * math.sin(cur_time * 25.0))
        w_surf = pygame.Surface((30, 20), pygame.SRCALPHA)
        pygame.draw.polygon(w_surf, (255, 60, 60, alpha), [(15, 18), (5, 4), (25, 4)])
        surf.blit(w_surf, (self.x - 15, 6))

class Player:
    def __init__(self, p_type, name, speed_stat, power_stat, fire_rate_stat):
        self.p_type = p_type
        self.name = name
        self.speed_stat = speed_stat
        self.power_stat = power_stat
        self.fire_rate_stat = fire_rate_stat
        self.clone_plane_timer = 0.0
        self.laser_weapon_timer = 0.0
        self.last_laser_time = 0.0
        self.laser_muzzle_flash_time = 0.0
        self.x = SCREEN_WIDTH // 2
        self.y = int(SCREEN_HEIGHT * 0.8)
        self.target_x = self.x
        self.target_y = self.y
        self.radius = 22
        self.hitbox_radius = 10
        self.shield_remain = 0.0
        self.invincible_timer = 0.0
        self.last_shot = 0.0
        self.is_alive = True
        self.graze_glow_timer = 0.0

    def get_real_speed(self):
        return CONFIG["BASE_PLAYER_SPEED"] + (self.speed_stat * CONFIG["STAT_SPEED_FACTOR"])

    def get_fire_interval(self):
        reduction = 1.0 - (min(10, self.fire_rate_stat) * CONFIG["FIRE_RATE_REDUCTION"])
        return max(0.065, CONFIG["BASE_FIRE_INTERVAL"] * reduction)

    def update_position(self, dt):
        if not self.is_alive:
            return
        if self.clone_plane_timer > 0:
            self.clone_plane_timer = max(0.0, self.clone_plane_timer - dt)
        if self.laser_weapon_timer > 0:
            self.laser_weapon_timer = max(0.0, self.laser_weapon_timer - dt)
        if self.invincible_timer > 0:
            self.invincible_timer = max(0.0, self.invincible_timer - dt)
        if self.graze_glow_timer > 0:
            self.graze_glow_timer = max(0.0, self.graze_glow_timer - dt)

        dx = self.target_x - self.x
        dy = self.target_y - self.y
        dist = math.hypot(dx, dy)
        max_step = self.get_real_speed() * 60.0 * dt

        if dist > 0.5:
            if dist <= max_step:
                self.x = self.target_x
                self.y = self.target_y
            else:
                self.x += (dx / dist) * max_step
                self.y += (dy / dist) * max_step

        max_limit_x = SCREEN_WIDTH - self.radius - (46 if self.clone_plane_timer > 0 else 10)
        self.x = max(self.radius + 10, min(max_limit_x, self.x))
        self.y = max(self.radius + 10, min(SCREEN_HEIGHT - self.radius - 10, self.y))

    def _fire_main(self, px, py, dmg, bullets):
        if self.p_type == 2:
            bullets.append(Bullet(px - 12, py - 20, 0, -15, dmg))
            bullets.append(Bullet(px + 12, py - 20, 0, -15, dmg))
        elif self.p_type == 1:
            bullets.append(Bullet(px, py - 24, 0, -14, dmg * 1.5, radius=7, color=COLOR_ORANGE))
        else:
            bullets.append(Bullet(px, py - 22, 0, -17, dmg))

    def shoot(self, current_time, bullets):
        if not self.is_alive:
            return
        dmg = max(1, self.power_stat)
        main_interval = self.get_fire_interval()
        if current_time - self.last_shot >= main_interval:
            self.last_shot = current_time
            self._fire_main(self.x, self.y, dmg, bullets)
            if self.clone_plane_timer > 0:
                self._fire_main(self.x + 42, self.y, dmg, bullets)

    def draw_single_ship(self, surf, cx, cy, cur_time):
        matrix = PIXEL_PLAYERS[self.p_type]
        if self.p_type == 0:
            cmap = {1: COLOR_CYAN, 2: COLOR_WHITE, 3: (0, 150, 255), 4: COLOR_YELLOW}
        elif self.p_type == 1:
            cmap = {1: (255, 60, 90), 2: COLOR_YELLOW, 3: COLOR_WHITE, 4: COLOR_ORANGE}
        else:
            cmap = {1: (100, 170, 255), 2: COLOR_WHITE, 3: COLOR_CYAN, 4: COLOR_YELLOW}
        draw_pixel_matrix(surf, cx, cy, matrix, cmap, pixel_size=4)

        if self.laser_weapon_timer > 0:
            pod_rect = pygame.Rect(cx - 28, cy - 8, 4, 18)
            pygame.draw.rect(surf, COLOR_CYAN, pod_rect, border_radius=2)
            pygame.draw.polygon(surf, COLOR_WHITE, [(cx - 26, cy - 13), (cx - 29, cy - 8), (cx - 23, cy - 8)])
            flash_elapsed = cur_time - self.laser_muzzle_flash_time
            if flash_elapsed < 0.15:
                spark_r = random.randint(4, 7)
                spark_col = COLOR_WHITE if (int(flash_elapsed * 40) % 2 == 0) else COLOR_CYAN
                pygame.draw.circle(surf, spark_col, (cx - 26, cy - 13), spark_r)
                pygame.draw.line(surf, COLOR_WHITE, (cx - 26 - spark_r, cy - 13), (cx - 26 + spark_r, cy - 13), 1)
                pygame.draw.line(surf, COLOR_WHITE, (cx - 26, cy - 13 - spark_r), (cx - 26, cy - 13 + spark_r), 1)

    def draw(self, surf, cur_time):
        if not self.is_alive:
            return
        if self.invincible_timer > 0 and (int(cur_time * 20) % 2 == 0):
            return
        if self.graze_glow_timer > 0:
            pygame.draw.circle(surf, COLOR_CYAN, (int(self.x), int(self.y)), int(CONFIG["GRAZE_DISTANCE"]), 1)
            graze_txt = FONT_LIST.render("GRAZE!", True, COLOR_CYAN)
            surf.blit(graze_txt, (self.x - graze_txt.get_width() // 2, self.y - 32))

        self.draw_single_ship(surf, self.x, self.y, cur_time)
        if self.clone_plane_timer > 0:
            self.draw_single_ship(surf, self.x + 42, self.y, cur_time)

        if self.shield_remain > 0:
            pygame.draw.circle(surf, COLOR_GREEN, (int(self.x), int(self.y)), self.radius + 14, 2)
            if self.clone_plane_timer > 0:
                pygame.draw.circle(surf, COLOR_GREEN, (int(self.x + 42), int(self.y)), self.radius + 14, 2)

        timer_strs = []
        if self.clone_plane_timer > 0:
            timer_strs.append(f"+CLONE {int(self.clone_plane_timer)}s")
        if self.laser_weapon_timer > 0:
            timer_strs.append(f"+LASER {self.laser_weapon_timer:.1f}s")

        if timer_strs:
            combined = " | ".join(timer_strs)
            t_surf = FONT_TIMER.render(combined, True, COLOR_CYAN)
            surf.blit(t_surf, (self.x - t_surf.get_width() // 2, self.y + self.radius + 10))

class Bullet:
    def __init__(self, x, y, vx, vy, dmg, radius=4, color=COLOR_YELLOW, is_enemy=False):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.dmg = dmg
        self.radius = radius
        self.color = color
        self.is_enemy = is_enemy

    def update(self):
        self.x += self.vx
        self.y += self.vy

    def draw(self, surf):
        pygame.draw.circle(surf, self.color, (int(self.x), int(self.y)), int(self.radius))

class Enemy:
    def __init__(self, max_hp, base_speed, design_id, origin_x=None, is_boss=False):
        self.origin_x = origin_x if origin_x is not None else random.randint(50, SCREEN_WIDTH - 50)
        self.x = float(self.origin_x)
        self.y = -60.0 if not is_boss else -90.0
        self.max_hp = max_hp
        self.hp = max_hp
        self.is_boss = is_boss
        speed_factor = random.uniform(0.70, 1.30)
        self.speed = 1.8 if is_boss else (base_speed * speed_factor)
        self.pattern_type = "BOSS_SWAY" if is_boss else random.choice(["STRAIGHT", "SINE", "SMOOTH_CURVE"])
        self.sine_phase = random.uniform(0, math.pi * 2)
        self.sine_amp = 95.0 if is_boss else random.uniform(35, 70)
        self.sine_freq = 1.4 if is_boss else random.uniform(1.8, 3.2)
        self.curve_vx = random.uniform(-1.8, 1.8)
        self.curve_timer = random.uniform(0.5, 1.5)
        self.last_boss_shot = 0.0
        self.design_id = design_id
        self.radius = 48 if is_boss else (20 if max_hp <= 5 else (25 if max_hp <= 12 else 30))

    def update(self, dt, current_game_time, enemy_bullets):
        if self.is_boss:
            if self.y < 90.0:
                self.y += self.speed
            self.x = (SCREEN_WIDTH // 2) + math.sin(current_game_time * self.sine_freq) * self.sine_amp
            if current_game_time - self.last_boss_shot >= 1.2:
                self.last_boss_shot = current_game_time
                enemy_bullets.append(Bullet(self.x - 28, self.y + 36, -0.6, 5.2, 1, radius=5, color=COLOR_RED, is_enemy=True))
                enemy_bullets.append(Bullet(self.x + 28, self.y + 36, 0.6, 5.2, 1, radius=5, color=COLOR_RED, is_enemy=True))
        else:
            self.y += self.speed
            if self.pattern_type == "SINE":
                self.x = self.origin_x + math.sin(current_game_time * self.sine_freq + self.sine_phase) * self.sine_amp
            elif self.pattern_type == "SMOOTH_CURVE":
                self.curve_timer -= dt
                if self.curve_timer <= 0:
                    self.curve_vx = random.uniform(-2.2, 2.2)
                    self.curve_timer = random.uniform(0.8, 1.8)
                self.x += self.curve_vx * 60.0 * dt
                if self.x <= self.radius:
                    self.x = self.radius
                    self.curve_vx = abs(self.curve_vx)
                elif self.x >= SCREEN_WIDTH - self.radius:
                    self.x = SCREEN_WIDTH - self.radius
                    self.curve_vx = -abs(self.curve_vx)

    def draw(self, surf):
        if self.is_boss:
            cmap = {1: (255, 30, 70), 2: (255, 160, 0), 3: COLOR_WHITE}
            draw_pixel_matrix(surf, self.x, self.y, PIXEL_BOSS, cmap, pixel_size=6)
            bar_w = 140
            hp_w = int(bar_w * max(0, (self.hp / self.max_hp)))
            bx = self.x - bar_w // 2
            by = self.y - self.radius - 14
            pygame.draw.rect(surf, COLOR_GRAY, (bx, by, bar_w, 6), border_radius=2)
            pygame.draw.rect(surf, COLOR_RED, (bx, by, hp_w, 6), border_radius=2)
            boss_lbl = FONT_LIST.render(f"BOSS HP: {self.hp}/{self.max_hp}", True, COLOR_RED)
            surf.blit(boss_lbl, (self.x - boss_lbl.get_width() // 2, by - 14))
        else:
            matrix = PIXEL_ENEMIES[self.design_id % len(PIXEL_ENEMIES)]
            theme_palettes = [
                {1: (255, 60, 100), 2: (255, 180, 0), 3: COLOR_WHITE},
                {1: (200, 50, 255), 2: COLOR_CYAN, 3: COLOR_WHITE},
                {1: (50, 240, 180), 2: COLOR_YELLOW, 3: COLOR_WHITE},
                {1: (255, 100, 40), 2: (255, 220, 80), 3: COLOR_WHITE}
            ]
            cmap = theme_palettes[self.design_id % len(theme_palettes)]
            psize = 4 if self.max_hp <= 10 else 5
            draw_pixel_matrix(surf, self.x, self.y, matrix, cmap, pixel_size=psize)
            bar_w = int(self.radius * 1.4)
            hp_w = int(bar_w * max(0, (self.hp / self.max_hp)))
            bx = self.x - bar_w // 2
            by = self.y - self.radius - 8
            pygame.draw.rect(surf, COLOR_GRAY, (bx, by, bar_w, 3))
            pygame.draw.rect(surf, COLOR_GREEN, (bx, by, hp_w, 3))

player = None
bullets = []
enemy_bullets = []
active_laser_lines = []
enemies = []
spawn_warnings = []
explosions = []
power_items = []

start_time = 0.0
last_spawn_time = 0.0
last_boss_spawn_time = 0.0
boss_warning_timer = 0.0
skill_gauge = 0.0
score = 0
last_dps_check_time = 0.0

death_time = 0.0
player_death_handled = False

PLACEHOLDER_TEXT = "Please enter your name"
player_name_input = ""
is_input_active = False

ALL_SLOT_OPTIONS = [
    ("POWER_UP", "POWER UP (+1)"),
    ("SPEED_UP", "SPEED UP (+1)"),
    ("FIRE_RATE", "FIRING RATE (+1)"),
    ("CLONE_SHIP", "CLONE SHIP (30s)"),
    ("LASER_WEAPON", "LASER WEAPON (30.5s)"),
    ("SHIELD", "SHIELD (30s)")
]

SLOT_WEIGHTS_DEFAULT = {
    "POWER_UP": 0.30,
    "SPEED_UP": 0.30,
    "FIRE_RATE": 0.30,
    "SHIELD": 0.10,
    "LASER_WEAPON": 0.10,
    "CLONE_SHIP": 0.05
}

slot_active_pool = []
slot_start_time = 0.0
slot_picked_code = None
slot_picked_label = None
slot_pick_time = 0.0
slot_is_selected = False
slot_last_tick_idx = -1
screen_clear_alpha = 0

def start_battle(selected_type):
    global player, bullets, enemy_bullets, active_laser_lines, enemies, spawn_warnings, explosions, power_items
    global start_time, last_spawn_time, last_boss_spawn_time, boss_warning_timer
    global skill_gauge, score, game_state, player_death_handled, current_tier, last_dps_check_time
    if selected_type == 0:
        player = Player(0, "Speed", speed_stat=3, power_stat=1, fire_rate_stat=1)
    elif selected_type == 1:
        player = Player(1, "Power", speed_stat=1, power_stat=3, fire_rate_stat=1)
    else:
        player = Player(2, "Twin", speed_stat=1, power_stat=1, fire_rate_stat=3)

    bullets.clear()
    enemy_bullets.clear()
    active_laser_lines.clear()
    enemies.clear()
    spawn_warnings.clear()
    explosions.clear()
    power_items.clear()
    start_time = time.time()
    last_spawn_time = start_time
    last_boss_spawn_time = start_time
    boss_warning_timer = 0.0
    last_dps_check_time = start_time
    skill_gauge = 0.0
    score = 0
    current_tier = 0
    player_death_handled = False
    game_state = STATE_BATTLE
    fetch_top10_async()

def trigger_slot_screen():
    global game_state, enemies, spawn_warnings, screen_clear_alpha, slot_is_selected, slot_picked_code, slot_picked_label, slot_active_pool, slot_start_time, slot_last_tick_idx
    add_screen_shake(8.0)
    for e in enemies:
        add_explosion(e.x, e.y, COLOR_MAGENTA)
    enemies.clear()
    enemy_bullets.clear()
    spawn_warnings.clear()
    active_laser_lines.clear()
    screen_clear_alpha = 255
    slot_is_selected = False
    slot_picked_code = None
    slot_picked_label = None
    slot_start_time = time.time()
    slot_last_tick_idx = -1

    pool = []
    for code, label in ALL_SLOT_OPTIONS:
        if code == "CLONE_SHIP" and player.clone_plane_timer > 0:
            continue
        if code == "POWER_UP" and player.power_stat >= 10:
            continue
        if code == "SPEED_UP" and player.speed_stat >= 10:
            continue
        if code == "FIRE_RATE" and player.fire_rate_stat >= 10:
            continue
        pool.append((code, label))

    if not pool:
        pool = [("SHIELD", "SHIELD (30s)"), ("LASER_WEAPON", "LASER WEAPON (30.5s)")]

    random.shuffle(pool)
    slot_active_pool = pool
    game_state = STATE_SLOT

def pick_slot_reward():
    codes = [opt[0] for opt in slot_active_pool]
    weights = [SLOT_WEIGHTS_DEFAULT.get(c, 0.1) for c in codes]
    chosen_code = random.choices(codes, weights=weights, k=1)[0]
    for code, label in slot_active_pool:
        if code == chosen_code:
            return code, label
    return slot_active_pool[0]

def apply_slot_reward(reward_code):
    global player
    if reward_code == "POWER_UP":
        player.power_stat = min(10, player.power_stat + 1)
    elif reward_code == "SPEED_UP":
        player.speed_stat = min(10, player.speed_stat + 1)
    elif reward_code == "FIRE_RATE":
        player.fire_rate_stat = min(10, player.fire_rate_stat + 1)
    elif reward_code == "CLONE_SHIP":
        player.clone_plane_timer = CONFIG["CLONE_SHIP_DURATION"]
    elif reward_code == "LASER_WEAPON":
        player.laser_weapon_timer = CONFIG["LASER_WEAPON_DURATION"]
        player.last_laser_time = time.time()
    elif reward_code == "SHIELD":
        player.shield_remain = CONFIG["SHIELD_DURATION"]

def add_explosion(x, y, color):
    fx_choice = random.randint(0, 4)
    explosions.append(ExplosionFX(x, y, fx_choice, color))
    if SFX_EXPLOSIONS:
        random.choice(SFX_EXPLOSIONS).play()

def draw_top10_hud():
    overlay = pygame.Surface((155, 175), pygame.SRCALPHA)
    overlay.fill((10, 15, 30, 76))
    screen.blit(overlay, (10, 10))

    border_surf = pygame.Surface((155, 175), pygame.SRCALPHA)
    pygame.draw.rect(border_surf, (0, 245, 255, 76), (0, 0, 155, 175), 1, border_radius=4)
    screen.blit(border_surf, (10, 10))

    title_surf = FONT_TOP10.render("== GLOBAL TOP 10 ==", True, (0, 245, 255))
    screen.blit(title_surf, (15, 14))

    board_data = top10_list if top10_list else [("OFFLINE", 0)]
    for idx, (p_name, p_sc) in enumerate(board_data[:10]):
        line_txt = f"{idx+1:>2}. {p_name[:9]:<9} {p_sc:>3}"
        line_col = COLOR_YELLOW if idx == 0 else (COLOR_WHITE if idx < 3 else (160, 170, 190))
        txt_surf = FONT_TOP10.render(line_txt, True, line_col)
        screen.blit(txt_surf, (15, 30 + idx * 14))

def draw_version_tag():
    ver_surf = FONT_VER.render(VERSION_STR, True, COLOR_VERSION_DIM)
    screen.blit(ver_surf, (8, SCREEN_HEIGHT - 18))

async def main():
    global game_state, current_tier, score, skill_gauge, shake_intensity, last_spawn_time
    global last_boss_spawn_time, boss_warning_timer, last_dps_check_time, death_time
    global player_death_handled, screen_clear_alpha, is_input_active, player_name_input
    global slot_is_selected, slot_picked_code, slot_picked_label, slot_pick_time, slot_last_tick_idx

    running = True

    while running:
        dt = clock.tick(FPS) / 1000.0
        cur_time = time.time()

        if shake_intensity > 0:
            shake_intensity = max(0.0, shake_intensity - shake_decay * dt)

        for st in stars:
            st.update()
        for pl in planets:
            pl.update()
        rare_space_manager.update(cur_time)

        for ex in explosions[:]:
            ex.update(dt)
            if ex.life <= 0:
                explosions.remove(ex)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if game_state == STATE_SELECT:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = event.pos
                    if 220 <= my <= 320:
                        start_battle(0)
                    elif 340 <= my <= 440:
                        start_battle(1)
                    elif 460 <= my <= 560:
                        start_battle(2)

            elif game_state == STATE_BATTLE:
                if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEMOTION):
                    if pygame.mouse.get_pressed()[0]:
                        tx, ty = event.pos
                        player.target_x = tx
                        player.target_y = ty - 120

            elif game_state == STATE_SLOT:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if not slot_is_selected and len(slot_active_pool) > 0:
                        slot_is_selected = True
                        slot_pick_time = cur_time
                        slot_picked_code, slot_picked_label = pick_slot_reward()

            elif game_state == STATE_GAMEOVER:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = event.pos
                    input_rect = pygame.Rect(SCREEN_WIDTH // 2 - 120, int(SCREEN_HEIGHT * 0.3) + 70, 240, 36)
                    btn_restart_rect = pygame.Rect(SCREEN_WIDTH // 2 - 90, int(SCREEN_HEIGHT * 0.3) + 125, 180, 42)

                    if input_rect.collidepoint(mx, my):
                        is_input_active = True
                    else:
                        is_input_active = False

                    if btn_restart_rect.collidepoint(mx, my):
                        entered = player_name_input.strip()
                        final_name = entered if entered else "No Name"
                        upload_score_async(final_name, score)
                        player_name_input = ""
                        game_state = STATE_SELECT

                if event.type == pygame.KEYDOWN and is_input_active:
                    if event.key == pygame.K_BACKSPACE:
                        player_name_input = player_name_input[:-1]
                    elif event.key == pygame.K_RETURN:
                        is_input_active = False
                    else:
                        char = event.unicode
                        if char and 32 <= ord(char) <= 126 and len(player_name_input) < 18:
                            player_name_input += char

        if game_state == STATE_SELECT:
            screen.fill(TIER_THEMES[0]["bg"])
            for pl in planets:
                pl.draw(screen)
            rare_space_manager.draw(screen)
            for st in stars:
                st.draw(screen, TIER_THEMES[0]["star_tint"])

            title = FONT_L.render("NEON FLIGHT: OVERDRIVE", True, COLOR_CYAN)
            sub = FONT_S.render("CHOOSE YOUR FIGHTER", True, COLOR_WHITE)
            screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 80))
            screen.blit(sub, (SCREEN_WIDTH // 2 - sub.get_width() // 2, 130))

            cards = [
                ("SPEED", "PWR 1 | SPD 3 | RATE 1", (30, 70, 95), 220, 0),
                ("POWER", "PWR 3 | SPD 1 | RATE 1", (95, 35, 55), 340, 1),
                ("TWIN",  "PWR 1 | SPD 1 | RATE 3", (45, 55, 95), 460, 2),
            ]
            for name, desc, col, y, p_type in cards:
                card_rect = pygame.Rect(35, y, SCREEN_WIDTH - 70, 90)
                pygame.draw.rect(screen, col, card_rect, border_radius=10)
                pygame.draw.rect(screen, COLOR_CYAN, card_rect, 2, border_radius=10)

                prev_x, prev_y = 75, y + 45
                matrix = PIXEL_PLAYERS[p_type]
                if p_type == 0:
                    cmap = {1: COLOR_CYAN, 2: COLOR_WHITE, 3: (0, 150, 255), 4: COLOR_YELLOW}
                elif p_type == 1:
                    cmap = {1: (255, 60, 90), 2: COLOR_YELLOW, 3: COLOR_WHITE, 4: COLOR_ORANGE}
                else:
                    cmap = {1: (100, 170, 255), 2: COLOR_WHITE, 3: COLOR_CYAN, 4: COLOR_YELLOW}
                draw_pixel_matrix(screen, prev_x, prev_y, matrix, cmap, pixel_size=3)

                txt_name = FONT_M.render(name, True, COLOR_WHITE)
                txt_desc = FONT_S.render(desc, True, COLOR_YELLOW)
                screen.blit(txt_name, (115, y + 20))
                screen.blit(txt_desc, (115, y + 52))

            draw_version_tag()

        elif game_state == STATE_BATTLE:
            elapsed = cur_time - start_time
            if player.shield_remain > 0:
                player.shield_remain = max(0.0, player.shield_remain - dt)

            player.update_position(dt)
            player.shoot(cur_time, bullets)

            if player.is_alive and player.laser_weapon_timer > 0 and cur_time - player.last_laser_time >= CONFIG["LASER_WEAPON_INTERVAL"]:
                player.last_laser_time = cur_time
                player.laser_muzzle_flash_time = cur_time

                fire_points = [(player.x - 26, player.y - 12)]
                if player.clone_plane_timer > 0:
                    fire_points.append((player.x + 42 - 26, player.y - 12))

                for fp in fire_points:
                    valid_targets = [e for e in enemies if e.y > 0 and e.hp > 0 and not e.is_boss]
                    if valid_targets:
                        valid_targets.sort(key=lambda e: math.hypot(e.x - fp[0], e.y - fp[1]))
                        target = valid_targets[0]

                        active_laser_lines.append(LaserBeamLine(fp, (target.x, target.y), cur_time))
                        target.hp = 0
                        if target in enemies:
                            enemies.remove(target)
                        score += 1
                        skill_gauge += CONFIG["GAUGE_PER_KILL"]
                        add_screen_shake(3.0)
                        add_explosion(target.x, target.y, COLOR_CYAN)

            active_laser_lines = [line for line in active_laser_lines if not line.is_expired(cur_time)]

            shots_per_sec = 1.0 / player.get_fire_interval()
            barrel_multiplier = 2 if player.clone_plane_timer > 0 else 1
            effective_dps = shots_per_sec * max(1, player.power_stat) * barrel_multiplier * CONFIG["HIT_PROBABILITY"]

            time_factor = min(1.0, elapsed / 180.0)

            wave_cycle = elapsed % 12.0
            if wave_cycle < 6.0:
                tempo_multiplier = 0.8
            elif wave_cycle < 9.0:
                tempo_multiplier = 1.0
            else:
                tempo_multiplier = 1.6

            boss_present = any(e.is_boss for e in enemies)
            if boss_present:
                tempo_multiplier *= 2.0

            target_hp_flow = max(2.5, effective_dps * CONFIG["TARGET_HP_PRESSURE_RATIO"] * (0.6 + time_factor * 0.7))
            base_interval = max(CONFIG["MIN_SPAWN_INTERVAL"], min(CONFIG["MAX_SPAWN_INTERVAL"], 1.1 - (time_factor * 0.65)))
            current_spawn_interval = base_interval * tempo_multiplier
            current_enemy_max_hp = min(CONFIG["MAX_ENEMY_HP_CAP"], max(2, int(target_hp_flow * current_spawn_interval)))
            
            current_tier = min(3, int(current_enemy_max_hp / 5.2))
            current_speed = CONFIG["BASE_ENEMY_SPEED"] + (time_factor * 3.5)

            if cur_time - last_boss_spawn_time >= CONFIG["BOSS_SPAWN_INTERVAL"]:
                last_boss_spawn_time = cur_time
                boss_warning_timer = 2.5
                add_screen_shake(6.0)

            if boss_warning_timer > 0:
                boss_warning_timer -= dt
                if boss_warning_timer <= 0:
                    boss_hp = int(120 + time_factor * 160)
                    enemies.append(Enemy(boss_hp, current_speed, 99, origin_x=SCREEN_WIDTH // 2, is_boss=True))
                    add_screen_shake(10.0)

            if cur_time - last_spawn_time > current_spawn_interval:
                last_spawn_time = cur_time
                warn_x = random.randint(50, SCREEN_WIDTH - 50)
                spawn_warnings.append(SpawnWarning(warn_x, spawn_delay=0.35))

            for w in spawn_warnings[:]:
                if w.is_ready(cur_time):
                    enemy_hp = random.randint(1, 3) if random.random() < 0.20 else random.randint(max(1, current_enemy_max_hp - 4), current_enemy_max_hp)
                    design_id = random.randint(0, 9)
                    enemies.append(Enemy(enemy_hp, current_speed, design_id, origin_x=w.x))
                    spawn_warnings.remove(w)

            if cur_time - last_dps_check_time >= 2.0:
                last_dps_check_time = cur_time
                total_enemy_hp = sum(e.hp for e in enemies)
                if len(enemies) >= 3 and (effective_dps * 3.0) < (total_enemy_hp * 0.5):
                    if len(power_items) == 0 and player.power_stat < 10:
                        power_items.append(PowerDropItem(player.x))

            for it in power_items[:]:
                it.update()
                if it.y > SCREEN_HEIGHT + 30:
                    power_items.remove(it)
                    continue
                if player.is_alive and math.hypot(player.x - it.x, player.y - it.y) < player.radius + it.base_radius:
                    player.power_stat = min(10, player.power_stat + 1)
                    add_screen_shake(2.0)
                    add_explosion(it.x, it.y, COLOR_ORANGE)
                    power_items.remove(it)

            for b in bullets[:]:
                b.update()
                if b.y < -15:
                    bullets.remove(b)

            for eb in enemy_bullets[:]:
                eb.update()
                if eb.y > SCREEN_HEIGHT + 20 or eb.x < -20 or eb.x > SCREEN_WIDTH + 20:
                    enemy_bullets.remove(eb)
                    continue

                if player.is_alive and player.invincible_timer <= 0:
                    dist_p1 = math.hypot(player.x - eb.x, player.y - eb.y)
                    dist_p2 = math.hypot((player.x + 42) - eb.x, player.y - eb.y) if player.clone_plane_timer > 0 else 9999
                    min_dist = min(dist_p1, dist_p2)

                    if min_dist <= player.hitbox_radius + eb.radius:
                        enemy_bullets.remove(eb)
                        if player.shield_remain > 0:
                            player.shield_remain = 0.0
                            player.invincible_timer = CONFIG["INVINCIBLE_TIME_ON_SHIELD_BREAK"]
                            add_screen_shake(7.0)
                            add_explosion(player.x, player.y, COLOR_GREEN)
                        else:
                            player.is_alive = False
                            death_time = cur_time
                            add_screen_shake(14.0)
                            add_explosion(player.x, player.y, COLOR_CYAN)
                            add_explosion(player.x, player.y, COLOR_MAGENTA)
                            if player.clone_plane_timer > 0:
                                add_explosion(player.x + 42, player.y, COLOR_CYAN)
                        break

            for e in enemies[:]:
                e.update(dt, elapsed, enemy_bullets)
                if not e.is_boss and e.y > SCREEN_HEIGHT + 45:
                    enemies.remove(e)
                    continue

                for b in bullets[:]:
                    dist = math.hypot(b.x - e.x, b.y - e.y)
                    if dist < b.radius + e.radius:
                        e.hp -= b.dmg
                        if b in bullets:
                            bullets.remove(b)
                        if e.hp <= 0:
                            if e in enemies:
                                enemies.remove(e)
                            score += 5 if e.is_boss else 1
                            skill_gauge += CONFIG["GAUGE_PER_KILL"] * (3 if e.is_boss else 1)
                            add_screen_shake(6.0 if e.is_boss else 2.5)
                            add_explosion(e.x, e.y, COLOR_YELLOW)
                            if e.is_boss:
                                add_explosion(e.x - 20, e.y - 15, COLOR_ORANGE)
                                add_explosion(e.x + 20, e.y + 15, COLOR_MAGENTA)
                            break

                if player.is_alive:
                    dist_p1 = math.hypot(player.x - e.x, player.y - e.y)
                    dist_p2 = math.hypot((player.x + 42) - e.x, player.y - e.y) if player.clone_plane_timer > 0 else 9999
                    min_dist = min(dist_p1, dist_p2)

                    if (player.hitbox_radius + e.radius) < min_dist <= (CONFIG["GRAZE_DISTANCE"] + e.radius):
                        skill_gauge = min(CONFIG["MAX_SKILL_GAUGE"], skill_gauge + CONFIG["GRAZE_GAUGE_BONUS"])
                        player.graze_glow_timer = 0.08
                        add_screen_shake(0.4)

                    if player.invincible_timer <= 0 and min_dist <= player.hitbox_radius + e.radius:
                        if player.shield_remain > 0:
                            player.shield_remain = 0.0
                            player.invincible_timer = CONFIG["INVINCIBLE_TIME_ON_SHIELD_BREAK"]
                            add_screen_shake(7.0)
                            if not e.is_boss and e in enemies:
                                enemies.remove(e)
                            add_explosion(e.x, e.y, COLOR_GREEN)
                        else:
                            player.is_alive = False
                            death_time = cur_time
                            add_screen_shake(14.0)
                            add_explosion(player.x, player.y, COLOR_CYAN)
                            add_explosion(player.x, player.y, COLOR_MAGENTA)
                            if player.clone_plane_timer > 0:
                                add_explosion(player.x + 42, player.y, COLOR_CYAN)

        if not player.is_alive and not player_death_handled:
            if cur_time - death_time > 0.8:
                player_death_handled = True
                game_state = STATE_GAMEOVER

        if skill_gauge >= CONFIG["MAX_SKILL_GAUGE"]:
            skill_gauge = 0.0
            trigger_slot_screen()

        render_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        theme = TIER_THEMES[current_tier]
        render_surf.fill(theme["bg"])
        for pl in planets:
            pl.draw(render_surf)
        rare_space_manager.draw(render_surf)
        for st in stars:
            st.draw(render_surf, theme["star_tint"])

        for w in spawn_warnings:
            w.draw(render_surf, cur_time)

        for it in power_items:
            it.draw(render_surf, cur_time)
            
        for b in bullets:
            b.draw(render_surf)

        for eb in enemy_bullets:
            eb.draw(render_surf)
            
        for line in active_laser_lines:
            line.draw(render_surf, cur_time)
            
        for e in enemies:
            e.draw(render_surf)
        for ex in explosions:
            ex.draw(render_surf)

        player.draw(render_surf, cur_time)

        if boss_warning_timer > 0:
            siren_alpha = int(100 + 90 * math.sin(cur_time * 20.0))
            siren_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            siren_surf.fill((255, 0, 0, siren_alpha // 3))
            render_surf.blit(siren_surf, (0, 0))

            warn_box = pygame.Rect(0, 160, SCREEN_WIDTH, 60)
            pygame.draw.rect(render_surf, (15, 0, 0, 200), warn_box)
            pygame.draw.line(render_surf, COLOR_RED, (0, 160), (SCREEN_WIDTH, 160), 2)
            pygame.draw.line(render_surf, COLOR_RED, (0, 220), (SCREEN_WIDTH, 220), 2)

            warn_txt = FONT_XL.render("! WARNING: ELITE BOSS APPROACHING !", True, COLOR_RED)
            render_surf.blit(warn_txt, (SCREEN_WIDTH // 2 - warn_txt.get_width() // 2, 175))

        shake_x = random.uniform(-shake_intensity, shake_intensity) if shake_intensity > 0 else 0
        shake_y = random.uniform(-shake_intensity, shake_intensity) if shake_intensity > 0 else 0
        screen.blit(render_surf, (shake_x, shake_y))

        draw_top10_hud()

        score_surf = FONT_M.render(f"SCORE: {score}", True, COLOR_WHITE)
        time_surf = FONT_S.render(f"TIME: {int(elapsed)}s", True, COLOR_YELLOW)
        screen.blit(score_surf, (SCREEN_WIDTH - 150, 15))
        screen.blit(time_surf, (SCREEN_WIDTH - 150, 38))

        info_x, info_y = 20, SCREEN_HEIGHT - 105
        p_txt = FONT_S.render(f"POWER : Lv.{player.power_stat}/10", True, COLOR_MAGENTA)
        s_txt = FONT_S.render(f"SPEED : Lv.{player.speed_stat}/10", True, COLOR_CYAN)
        r_txt = FONT_S.render(f"RATE  : Lv.{player.fire_rate_stat}/10", True, COLOR_YELLOW)
        sh_txt = FONT_S.render(f"SHIELD: {player.shield_remain:.1f}s" if player.shield_remain > 0 else "SHIELD: OFF", True, COLOR_GREEN if player.shield_remain > 0 else COLOR_GRAY)
        screen.blit(p_txt, (info_x, info_y))
        screen.blit(s_txt, (info_x, info_y + 18))
        screen.blit(r_txt, (info_x, info_y + 36))
        screen.blit(sh_txt, (info_x, info_y + 54))

        gauge_w, gauge_h = 130, 16
        gx, gy = SCREEN_WIDTH - gauge_w - 20, SCREEN_HEIGHT - 40
        pygame.draw.rect(screen, COLOR_GRAY, (gx, gy, gauge_w, gauge_h), border_radius=4)
        current_gw = int(gauge_w * (min(skill_gauge, CONFIG["MAX_SKILL_GAUGE"]) / CONFIG["MAX_SKILL_GAUGE"]))
        pygame.draw.rect(screen, COLOR_CYAN, (gx, gy, current_gw, gauge_h), border_radius=4)
        g_title = FONT_S.render("SKILL GAUGE", True, COLOR_CYAN)
        screen.blit(g_title, (gx, gy - 20))

        draw_version_tag()

    elif game_state == STATE_SLOT:
        theme = TIER_THEMES[current_tier]
        screen.fill(theme["bg"])
        for pl in planets:
            pl.draw(screen)
        rare_space_manager.draw(screen)
        for st in stars:
            st.draw(screen, theme["star_tint"])

        if screen_clear_alpha > 0:
            flash_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            flash_surf.fill(COLOR_WHITE)
            flash_surf.set_alpha(int(screen_clear_alpha))
            screen.blit(flash_surf, (0, 0))
            screen_clear_alpha = max(0, screen_clear_alpha - (dt * 300))

        for ex in explosions:
            ex.draw(screen)

        title = FONT_L.render("ALL ENEMIES CLEARED!", True, COLOR_MAGENTA)
        screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 40))

        list_box = pygame.Rect(30, 80, SCREEN_WIDTH - 60, 120)
        pygame.draw.rect(screen, (15, 20, 38), list_box, border_radius=8)
        pygame.draw.rect(screen, COLOR_CYAN, list_box, 1, border_radius=8)
        list_hdr = FONT_S.render("[ AVAILABLE SKILL OPTIONS ]", True, COLOR_CYAN)
        screen.blit(list_hdr, (list_box.centerx - list_hdr.get_width() // 2, 88))

        for idx, (code, label) in enumerate(slot_active_pool):
            col_x = 48 + (idx % 2) * 195
            row_y = 112 + (idx // 2) * 26
            dot_col = COLOR_YELLOW if (slot_is_selected and code == slot_picked_code) else (170, 180, 205)
            opt_txt = FONT_LIST.render(f"- {label}", True, dot_col)
            screen.blit(opt_txt, (col_x, row_y))

        slot_box = pygame.Rect(45, 300, SCREEN_WIDTH - 90, 110)
        pygame.draw.rect(screen, (22, 28, 55), slot_box, border_radius=14)

        slot_elapsed = cur_time - slot_start_time

        if not slot_is_selected and slot_elapsed >= CONFIG["SLOT_AUTO_PICK_TIMEOUT"] and len(slot_active_pool) > 0:
            slot_is_selected = True
            slot_pick_time = cur_time
            slot_picked_code, slot_picked_label = pick_slot_reward()

        if not slot_is_selected:
            cur_idx = int(slot_elapsed / CONFIG["SLOT_CYCLE_INTERVAL"]) % len(slot_active_pool)
            if cur_idx != slot_last_tick_idx:
                slot_last_tick_idx = cur_idx
                if SFX_SLOT_TICK:
                    SFX_SLOT_TICK.play()

            disp_label = slot_active_pool[cur_idx][1]
            pygame.draw.rect(screen, COLOR_YELLOW, slot_box, 3, border_radius=14)

            guide_txt = FONT_M.render("TAP / CLICK ANYWHERE TO STOP!", True, COLOR_CYAN)
            screen.blit(guide_txt, (SCREEN_WIDTH // 2 - guide_txt.get_width() // 2, 440))

            remain_sec = max(0, int(math.ceil(CONFIG["SLOT_AUTO_PICK_TIMEOUT"] - slot_elapsed)))
            auto_txt = FONT_S.render(f"AUTO-PICK IN {remain_sec}s, GAME STARTS", True, COLOR_YELLOW)
            screen.blit(auto_txt, (SCREEN_WIDTH // 2 - auto_txt.get_width() // 2, 475))
        else:
            disp_label = slot_picked_label
            pygame.draw.rect(screen, COLOR_GREEN, slot_box, 4, border_radius=14)
            chosen_txt = FONT_L.render("SELECTED!", True, COLOR_GREEN)
            screen.blit(chosen_txt, (SCREEN_WIDTH // 2 - chosen_txt.get_width() // 2, 450))

            if cur_time - slot_pick_time >= CONFIG["SLOT_RESULT_DISPLAY_TIME"]:
                apply_slot_reward(slot_picked_code)
                game_state = STATE_BATTLE

        lbl_surf = FONT_M.render(disp_label, True, COLOR_WHITE)
        screen.blit(lbl_surf, (slot_box.centerx - lbl_surf.get_width() // 2, slot_box.centery - lbl_surf.get_height() // 2))

        draw_version_tag()

    elif game_state == STATE_GAMEOVER:
        screen.fill(TIER_THEMES[0]["bg"])
        for pl in planets:
            pl.draw(screen)
        rare_space_manager.draw(screen)
        for st in stars:
            st.draw(screen, TIER_THEMES[0]["star_tint"])
        for ex in explosions:
            ex.draw(screen)

        pop_y = int(SCREEN_HEIGHT * 0.3)
        pop_w, pop_h = 320, 220
        pop_rect = pygame.Rect(SCREEN_WIDTH // 2 - pop_w // 2, pop_y - 20, pop_w, pop_h)
        pygame.draw.rect(screen, COLOR_DARK_BLUE, pop_rect, border_radius=14)
        pygame.draw.rect(screen, COLOR_MAGENTA, pop_rect, 2, border_radius=14)

        go_title = FONT_L.render("GAME OVER", True, COLOR_MAGENTA)
        sc_txt = FONT_M.render(f"FINAL SCORE: {score}", True, COLOR_YELLOW)
        screen.blit(go_title, (SCREEN_WIDTH // 2 - go_title.get_width() // 2, pop_y - 5))
        screen.blit(sc_txt, (SCREEN_WIDTH // 2 - sc_txt.get_width() // 2, pop_y + 35))

        input_rect = pygame.Rect(SCREEN_WIDTH // 2 - 120, pop_y + 70, 240, 36)
        input_border_col = COLOR_CYAN if is_input_active else COLOR_GRAY
        pygame.draw.rect(screen, (10, 15, 30), input_rect, border_radius=6)
        pygame.draw.rect(screen, input_border_col, input_rect, 2, border_radius=6)

        if not player_name_input and not is_input_active:
            name_surf = FONT_S.render(PLACEHOLDER_TEXT, True, (110, 120, 145))
        else:
            cursor_str = "_" if (is_input_active and int(cur_time * 2) % 2 == 0) else ""
            name_surf = FONT_S.render(f"{player_name_input}{cursor_str}", True, COLOR_WHITE)
        screen.blit(name_surf, (input_rect.x + 10, input_rect.y + 8))

        btn_rect = pygame.Rect(SCREEN_WIDTH // 2 - 90, pop_y + 125, 180, 42)
        pygame.draw.rect(screen, COLOR_CYAN, btn_rect, border_radius=8)
        btn_txt = FONT_M.render("RESTART", True, COLOR_DARK_BLUE)
        screen.blit(btn_txt, (btn_rect.centerx - btn_txt.get_width() // 2, btn_rect.centery - btn_txt.get_height() // 2))

        draw_version_tag()

    pygame.display.flip()
    await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(main())